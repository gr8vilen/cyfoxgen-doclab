#!/usr/bin/env python3
"""
Docker Lab Manager - Deploy containers via HTTP API with unique IPs and Web Dashboard
"""

from flask import Flask, request, jsonify, render_template_string
import docker
import ipaddress
import json
import logging
import os
import threading
import time
import random
import string
import subprocess

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Docker client
client = docker.from_env()

# Container tracking
containers = {}
network_manager = None

# Generate random password on startup
def generate_password():
    return ''.join(random.choices(string.ascii_letters + string.digits, k=8))

API_PASSWORD = generate_password()
print(f"\n{'='*50}")
print(f"🔐 DOCKER LAB MANAGER CREDENTIALS")
print(f"{'='*50}")
print(f"📍 URL: http://localhost:62111")
print(f"🔑 Password: {API_PASSWORD}")
print(f"{'='*50}\n")

class NetworkManager:
    def __init__(self):
        self.network_name = "lab-network"
        self.subnet = "172.20.0.0/16"
        self.gateway = "172.20.0.1"
        self.ip_pool = self._generate_ip_pool()
        self.used_ips = set()
        self.setup_network()
    
    def _generate_ip_pool(self):
        """Generate available IP addresses"""
        network = ipaddress.IPv4Network(self.subnet, strict=False)
        # Skip network, gateway, and broadcast addresses
        return [str(ip) for ip in network.hosts()][1:254]  # Skip first IP (gateway)
    
    def setup_network(self):
        """Create or get the lab network"""
        try:
            self.network = client.networks.get(self.network_name)
            logger.info(f"Using existing network: {self.network_name}")
        except docker.errors.NotFound:
            self.network = client.networks.create(
                self.network_name,
                driver="bridge",
                ipam=docker.types.IPAMConfig(
                    pool_configs=[
                        docker.types.IPAMPool(
                            subnet=self.subnet,
                            gateway=self.gateway
                        )
                    ]
                ),
                attachable=True
            )
            logger.info(f"Created network: {self.network_name}")
    
    def get_next_ip(self):
        """Get next available IP address"""
        for ip in self.ip_pool:
            if ip not in self.used_ips:
                self.used_ips.add(ip)
                return ip
        raise Exception("No available IP addresses")
    
    def release_ip(self, ip):
        """Release an IP address"""
        self.used_ips.discard(ip)

# Dashboard HTML Template
DASHBOARD_HTML = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🐳 Docker Lab Manager - Hacker Terminal</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
            color: #00ff00;
            font-family: 'Courier New', monospace;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        .matrix-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            opacity: 0.1;
        }
        
        .header {
            background: linear-gradient(90deg, #000 0%, #001100 50%, #000 100%);
            border-bottom: 2px solid #00ff00;
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 20px rgba(0, 255, 0, 0.3);
        }
        
        .header h1 {
            color: #00ff00;
            text-shadow: 0 0 10px #00ff00;
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .credentials {
            background: rgba(0, 50, 0, 0.8);
            border: 1px solid #00ff00;
            border-radius: 8px;
            padding: 15px;
            margin: 20px auto;
            max-width: 600px;
            text-align: center;
        }
        
        .credential-item {
            margin: 8px 0;
            font-size: 1.1em;
        }
        
        .password {
            color: #ffff00;
            font-weight: bold;
            text-shadow: 0 0 5px #ffff00;
        }
        
        .container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            padding: 20px;
            height: calc(100vh - 200px);
        }
        
        .panel {
            background: rgba(0, 20, 0, 0.9);
            border: 2px solid #00ff00;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 20px rgba(0, 255, 0, 0.2);
        }
        
        .panel h2 {
            color: #00ff00;
            text-shadow: 0 0 8px #00ff00;
            margin-bottom: 15px;
            border-bottom: 1px solid #00ff00;
            padding-bottom: 8px;
        }
        
        .logs {
            height: calc(100% - 60px);
            overflow-y: auto;
            background: #000;
            border: 1px solid #00ff00;
            border-radius: 5px;
            padding: 10px;
            font-size: 12px;
            line-height: 1.4;
        }
        
        .log-entry {
            margin-bottom: 5px;
            opacity: 0.8;
        }
        
        .log-entry.info { color: #00ff00; }
        .log-entry.warning { color: #ffff00; }
        .log-entry.error { color: #ff0000; }
        
        .containers-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
            height: calc(100% - 60px);
            overflow-y: auto;
        }
        
        .container-card {
            background: linear-gradient(135deg, #001100 0%, #002200 100%);
            border: 1px solid #00ff00;
            border-radius: 8px;
            padding: 15px;
            transition: all 0.3s ease;
            position: relative;
            min-height: 200px;
        }
        
        .container-card:hover {
            border-color: #00ffff;
            box-shadow: 0 0 15px rgba(0, 255, 255, 0.3);
        }
        
        .container-header {
            border-bottom: 1px solid #00ff00;
            padding-bottom: 8px;
            margin-bottom: 10px;
        }
        
        .container-name {
            color: #00ffff;
            font-weight: bold;
            font-size: 1.1em;
        }
        
        .container-ip {
            color: #ffff00;
            margin-top: 4px;
        }
        
        .container-status {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: bold;
        }
        
        .status-running {
            background: #00ff00;
            color: #000;
        }
        
        .status-stopped {
            background: #ff0000;
            color: #fff;
        }
        
        .container-logs {
            background: #000;
            border: 1px solid #333;
            border-radius: 4px;
            padding: 8px;
            height: 100px;
            overflow-y: auto;
            font-size: 10px;
            margin-top: 10px;
        }
        
        .scrollbar::-webkit-scrollbar {
            width: 8px;
        }
        
        .scrollbar::-webkit-scrollbar-track {
            background: #000;
        }
        
        .scrollbar::-webkit-scrollbar-thumb {
            background: #00ff00;
            border-radius: 4px;
        }
        
        .blink {
            animation: blink 1s infinite;
        }
        
        @keyframes blink {
            0%, 50% { opacity: 1; }
            51%, 100% { opacity: 0; }
        }
        
        .terminal-cursor::after {
            content: "█";
            animation: blink 1s infinite;
            color: #00ff00;
        }
    </style>
</head>
<body>
    <canvas class="matrix-bg" id="matrix"></canvas>
    
    <div class="header">
        <h1>🐳 DOCKER LAB MANAGER</h1>
        <div class="credentials">
            <div class="credential-item">📍 <strong>IP:</strong> localhost</div>
            <div class="credential-item">🔌 <strong>Port:</strong> 62111</div>
            <div class="credential-item">🔑 <strong>Password:</strong> <span class="password">{{ password }}</span></div>
        </div>
    </div>
    
    <div class="container">
        <div class="panel">
            <h2>📊 System Logs <span class="terminal-cursor"></span></h2>
            <div class="logs scrollbar" id="systemLogs">
                <div class="log-entry info">[SYSTEM] Docker Lab Manager initialized</div>
                <div class="log-entry info">[NETWORK] Lab network ready: 172.20.0.0/16</div>
                <div class="log-entry info">[AUTH] Password generated: {{ password }}</div>
            </div>
        </div>
        
        <div class="panel">
            <h2>🚀 Active Containers <span id="containerCount">(0)</span></h2>
            <div class="containers-grid scrollbar" id="containersGrid">
                <div style="text-align: center; color: #666; margin-top: 50px;">
                    No containers deployed yet...<br>
                    <small>Use API with password to deploy containers</small>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Matrix background effect
        const canvas = document.getElementById('matrix');
        const ctx = canvas.getContext('2d');
        
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        
        const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789@#$%^&*()';
        const fontSize = 10;
        const columns = canvas.width / fontSize;
        const drops = [];
        
        for (let x = 0; x < columns; x++) {
            drops[x] = 1;
        }
        
        function drawMatrix() {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            ctx.fillStyle = '#00ff00';
            ctx.font = fontSize + 'px monospace';
            
            for (let i = 0; i < drops.length; i++) {
                const text = letters[Math.floor(Math.random() * letters.length)];
                ctx.fillText(text, i * fontSize, drops[i] * fontSize);
                
                if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
                    drops[i] = 0;
                }
                drops[i]++;
            }
        }
        
        setInterval(drawMatrix, 35);
        
        // Auto-refresh data
        function addLog(message, type = 'info') {
            const logs = document.getElementById('systemLogs');
            const timestamp = new Date().toLocaleTimeString();
            const logEntry = document.createElement('div');
            logEntry.className = `log-entry ${type}`;
            logEntry.innerHTML = `[${timestamp}] ${message}`;
            logs.appendChild(logEntry);
            logs.scrollTop = logs.scrollHeight;
            
            // Keep only last 100 logs
            while (logs.children.length > 100) {
                logs.removeChild(logs.firstChild);
            }
        }
        
        function updateContainers() {
            fetch('/containers')
                .then(response => response.json())
                .then(data => {
                    const grid = document.getElementById('containersGrid');
                    const count = document.getElementById('containerCount');
                    
                    // Filter out management container
                    const containers = data.containers.filter(c => !c.name.includes('docker-lab-manager'));
                    count.textContent = `(${containers.length})`;
                    
                    if (containers.length === 0) {
                        grid.innerHTML = `
                            <div style="text-align: center; color: #666; margin-top: 50px;">
                                No containers deployed yet...<br>
                                <small>Use API with password to deploy containers</small>
                            </div>
                        `;
                        return;
                    }
                    
                    grid.innerHTML = '';
                    
                    containers.forEach(container => {
                        const card = document.createElement('div');
                        card.className = 'container-card';
                        card.innerHTML = `
                            <div class="container-status status-${container.status}">
                                ${container.status.toUpperCase()}
                            </div>
                            <div class="container-header">
                                <div class="container-name">📦 ${container.name}</div>
                                <div class="container-ip">🌐 ${container.ip}</div>
                                <div style="color: #888; font-size: 12px; margin-top: 4px;">
                                    ${container.image}
                                </div>
                            </div>
                            <div class="container-logs scrollbar" id="logs-${container.id}">
                                Loading logs...
                            </div>
                        `;
                        grid.appendChild(card);
                        
                        // Fetch container logs
                        fetch(`/containers/${container.id}/logs`)
                            .then(response => response.json())
                            .then(logData => {
                                const logDiv = document.getElementById(`logs-${container.id}`);
                                if (logDiv) {
                                    logDiv.innerHTML = logData.logs ? 
                                        logData.logs.split('\\n').slice(-10).join('<br>') : 
                                        'No logs available';
                                }
                            })
                            .catch(() => {
                                const logDiv = document.getElementById(`logs-${container.id}`);
                                if (logDiv) logDiv.innerHTML = 'Error loading logs';
                            });
                    });
                })
                .catch(error => {
                    addLog(`Error fetching containers: ${error.message}`, 'error');
                });
        }
        
        // Initial load and refresh every 5 seconds
        updateContainers();
        setInterval(updateContainers, 5000);
        
        // Add periodic system logs
        setInterval(() => {
            const messages = [
                'System monitoring active',
                'Network status: OK',
                'Container health check complete',
                'IP pool status: Available',
                'Security scan: All clear'
            ];
            addLog(messages[Math.floor(Math.random() * messages.length)]);
        }, 15000);
        
        // Resize canvas on window resize
        window.addEventListener('resize', () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        });
    </script>
</body>
</html>
'''

@app.route('/', methods=['GET'])
def dashboard():
    """Serve the dashboard"""
    return render_template_string(DASHBOARD_HTML, password=API_PASSWORD)

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({"status": "healthy", "containers": len(containers)})

@app.route('/deploy', methods=['POST'])
def deploy_container():
    """Deploy a new container with unique IP - requires password"""
    try:
        data = request.get_json()
        
        # Check password
        if not data or data.get('password') != API_PASSWORD:
            logger.warning("Unauthorized deployment attempt")
            return jsonify({"error": "Invalid password"}), 401
        
        # Validate required fields
        if 'image' not in data:
            return jsonify({"error": "Missing 'image' field"}), 400
        
        image = data['image']
        name = data.get('name', f"lab-container-{int(time.time())}")
        environment = data.get('environment', {})
        volumes = data.get('volumes', {})
        command = data.get('command')
        
        logger.info(f"Deploying container: {name} with image: {image}")
        
        # Create container without port mapping
        container = client.containers.run(
            image=image,
            name=name,
            environment=environment,
            volumes=volumes,
            command=command,
            network=network_manager.network_name,
            detach=True,
            remove=False
        )
        
        # Get container IP
        container.reload()
        container_ip = container.attrs['NetworkSettings']['Networks'][network_manager.network_name]['IPAddress']
        
        # Get exposed ports from container (for info only)
        exposed_ports = []
        if container.attrs.get('Config', {}).get('ExposedPorts'):
            exposed_ports = list(container.attrs['Config']['ExposedPorts'].keys())
        
        # Store container info
        container_info = {
            'id': container.id,
            'name': name,
            'image': image,
            'ip': container_ip,
            'status': container.status,
            'exposed_ports': exposed_ports,
            'created': time.time(),
            'access_url': f"http://{container_ip}" if '80/tcp' in exposed_ports else None
        }
        containers[container.id] = container_info
        
        logger.info(f"✅ Deployed container {name} with IP {container_ip}")
        
        return jsonify({
            "success": True,
            "container": container_info,
            "message": f"Container accessible at IP {container_ip}"
        }), 201
        
    except docker.errors.ImageNotFound:
        logger.error(f"❌ Image '{image}' not found")
        return jsonify({"error": f"Image '{image}' not found"}), 404
    except Exception as e:
        logger.error(f"❌ Deployment error: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/containers', methods=['GET'])
def list_containers():
    """List all managed containers"""
    # Refresh container status
    for container_id in list(containers.keys()):
        try:
            container = client.containers.get(container_id)
            containers[container_id]['status'] = container.status
        except docker.errors.NotFound:
            # Container was removed externally
            container_info = containers.pop(container_id)
            if network_manager:
                network_manager.release_ip(container_info['ip'])
    
    return jsonify({"containers": list(containers.values())})

@app.route('/containers/<container_id>', methods=['GET'])
def get_container(container_id):
    """Get specific container info"""
    if container_id not in containers:
        return jsonify({"error": "Container not found"}), 404
    
    try:
        container = client.containers.get(container_id)
        containers[container_id]['status'] = container.status
        return jsonify({"container": containers[container_id]})
    except docker.errors.NotFound:
        containers.pop(container_id, None)
        return jsonify({"error": "Container not found"}), 404

@app.route('/containers/<container_id>', methods=['DELETE'])
def remove_container(container_id):
    """Remove a container - requires password"""
    data = request.get_json() or {}
    
    # Check password
    if data.get('password') != API_PASSWORD:
        return jsonify({"error": "Invalid password"}), 401
    
    if container_id not in containers:
        return jsonify({"error": "Container not found"}), 404
    
    try:
        container = client.containers.get(container_id)
        container.remove(force=True)
        
        # Release IP and remove from tracking
        container_info = containers.pop(container_id)
        network_manager.release_ip(container_info['ip'])
        
        logger.info(f"🗑️ Removed container {container_info['name']}")
        
        return jsonify({"success": True, "message": "Container removed"})
        
    except docker.errors.NotFound:
        containers.pop(container_id, None)
        return jsonify({"error": "Container not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/containers/<container_id>/logs', methods=['GET'])
def get_container_logs(container_id):
    """Get container logs"""
    if container_id not in containers:
        return jsonify({"error": "Container not found"}), 404
    
    try:
        container = client.containers.get(container_id)
        logs = container.logs(tail=50).decode('utf-8', errors='ignore')
        return jsonify({"logs": logs})
    except docker.errors.NotFound:
        return jsonify({"error": "Container not found"}), 404
    except Exception as e:
        return jsonify({"logs": f"Error retrieving logs: {str(e)}"})

@app.route('/cleanup', methods=['POST'])
def cleanup_all():
    """Remove all managed containers - requires password"""
    data = request.get_json() or {}
    
    # Check password
    if data.get('password') != API_PASSWORD:
        return jsonify({"error": "Invalid password"}), 401
    
    removed = []
    for container_id in list(containers.keys()):
        try:
            container = client.containers.get(container_id)
            container.remove(force=True)
            container_info = containers.pop(container_id)
            network_manager.release_ip(container_info['ip'])
            removed.append(container_info['name'])
            logger.info(f"🗑️ Cleaned up container: {container_info['name']}")
        except docker.errors.NotFound:
            containers.pop(container_id, None)
    
    return jsonify({"success": True, "removed": removed})

def cleanup_orphaned_containers():
    """Background task to clean up orphaned containers"""
    while True:
        try:
            time.sleep(60)  # Check every minute
            for container_id in list(containers.keys()):
                try:
                    container = client.containers.get(container_id)
                    if container.status == 'exited':
                        logger.info(f"🔄 Cleaning up exited container: {container.name}")
                        container.remove()
                        container_info = containers.pop(container_id)
                        network_manager.release_ip(container_info['ip'])
                except docker.errors.NotFound:
                    container_info = containers.pop(container_id, None)
                    if container_info and network_manager:
                        network_manager.release_ip(container_info['ip'])
        except Exception as e:
            logger.error(f"Cleanup error: {e}")

if __name__ == '__main__':
    # Initialize network manager
    network_manager = NetworkManager()
    
    # Start cleanup thread
    cleanup_thread = threading.Thread(target=cleanup_orphaned_containers, daemon=True)
    cleanup_thread.start()
    
    # Start Flask app on port 62111
    app.run(host='0.0.0.0', port=62111, debug=False)